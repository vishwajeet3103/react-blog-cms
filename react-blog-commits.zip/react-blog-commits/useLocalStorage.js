import { useState, useEffect } from "react";

/**
 * useLocalStorage
 * Drop-in replacement for useState that persists value in localStorage.
 *
 * @param {string} key - localStorage key
 * @param {*} initialValue - default value if key not found
 * @returns [storedValue, setValue]
 */
export function useLocalStorage(key, initialValue) {
  const [storedValue, setStoredValue] = useState(() => {
    try {
      const item = localStorage.getItem(key);
      return item ? JSON.parse(item) : initialValue;
    } catch {
      return initialValue;
    }
  });

  useEffect(() => {
    try {
      localStorage.setItem(key, JSON.stringify(storedValue));
    } catch {
      console.error(`useLocalStorage: failed to save key "${key}"`);
    }
  }, [key, storedValue]);

  const setValue = (value) => {
    setStoredValue((prev) =>
      typeof value === "function" ? value(prev) : value
    );
  };

  const removeValue = () => {
    localStorage.removeItem(key);
    setStoredValue(initialValue);
  };

  return [storedValue, setValue, removeValue];
}
