import { useState, useEffect } from "react";
import "./ReadingProgress.css";

/**
 * ReadingProgress
 * Thin bar at the top of the page that fills as the user scrolls.
 * Show on post detail pages only.
 */
export default function ReadingProgress() {
  const [progress, setProgress] = useState(0);

  useEffect(() => {
    const handleScroll = () => {
      const el = document.documentElement;
      const scrollTop = el.scrollTop || document.body.scrollTop;
      const scrollHeight = el.scrollHeight - el.clientHeight;
      if (scrollHeight <= 0) return;
      setProgress(Math.min(100, (scrollTop / scrollHeight) * 100));
    };

    window.addEventListener("scroll", handleScroll, { passive: true });
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  return (
    <div className="reading-progress">
      <div className="reading-progress__bar" style={{ width: `${progress}%` }} />
    </div>
  );
}
