import { useState, useEffect } from "react";

/**
 * useDebounce
 * Delays updating the returned value until after the specified delay.
 * Used to prevent firing search on every keystroke.
 *
 * @param {*} value - the value to debounce
 * @param {number} delay - milliseconds to wait (default 300)
 * @returns debounced value
 */
export function useDebounce(value, delay = 300) {
  const [debouncedValue, setDebouncedValue] = useState(value);

  useEffect(() => {
    const timer = setTimeout(() => {
      setDebouncedValue(value);
    }, delay);

    return () => clearTimeout(timer);
  }, [value, delay]);

  return debouncedValue;
}
