import { Link } from "react-router-dom";
import "./NotFound.css";

export default function NotFound() {
  return (
    <div className="notfound">
      <div className="notfound__inner">
        <span className="notfound__code">404</span>
        <h1 className="notfound__title">Page Not Found</h1>
        <p className="notfound__desc">The page you're looking for doesn't exist or has been moved.</p>
        <Link to="/" className="notfound__btn">← Back to Home</Link>
      </div>
    </div>
  );
}
