import { BrowserRouter, Routes, Route } from "react-router-dom";
import { BlogProvider } from "./context/BlogContext";
import Navbar from "./components/Navbar";
import Footer from "./components/Footer";
import Home from "./pages/Home";
import PostDetail from "./pages/PostDetail";
import CMS from "./pages/CMS";
import PostEditor from "./pages/PostEditor";
import "./styles/global.css";

export default function App() {
  return (
    <BlogProvider>
      <BrowserRouter>
        <div style={{ display: "flex", flexDirection: "column", minHeight: "100vh" }}>
          <Navbar />
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/post/:slug" element={<PostDetail />} />
            <Route path="/cms" element={<CMS />} />
            <Route path="/cms/new" element={<PostEditor />} />
            <Route path="/cms/edit/:id" element={<PostEditor />} />
          </Routes>
          <Footer />
        </div>
      </BrowserRouter>
    </BlogProvider>
  );
}
