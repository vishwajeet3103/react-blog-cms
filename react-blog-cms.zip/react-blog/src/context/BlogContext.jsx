import { createContext, useContext, useState, useEffect } from "react";
import { posts as initialPosts } from "../data/posts";

const BlogContext = createContext(null);

export function BlogProvider({ children }) {
  const [posts, setPosts] = useState(() => {
    const saved = localStorage.getItem("blog_posts");
    return saved ? JSON.parse(saved) : initialPosts;
  });
  const [searchQuery, setSearchQuery] = useState("");
  const [activeCategory, setActiveCategory] = useState("All");

  useEffect(() => {
    localStorage.setItem("blog_posts", JSON.stringify(posts));
  }, [posts]);

  const addPost = (post) => {
    const newPost = {
      ...post,
      id: Date.now(),
      slug: post.title.toLowerCase().replace(/\s+/g, "-").replace(/[^a-z0-9-]/g, ""),
      date: new Date().toISOString().split("T")[0],
      readTime: `${Math.max(1, Math.ceil(post.content.split(" ").length / 200))} min`,
      cover: post.cover || "https://images.unsplash.com/photo-1486312338219-ce68d2c6f44d?w=800&q=80",
    };
    setPosts((prev) => [newPost, ...prev]);
    return newPost;
  };

  const updatePost = (id, updates) => {
    setPosts((prev) =>
      prev.map((p) =>
        p.id === id
          ? {
              ...p,
              ...updates,
              slug: updates.title
                ? updates.title.toLowerCase().replace(/\s+/g, "-").replace(/[^a-z0-9-]/g, "")
                : p.slug,
              readTime: updates.content
                ? `${Math.max(1, Math.ceil(updates.content.split(" ").length / 200))} min`
                : p.readTime,
            }
          : p
      )
    );
  };

  const deletePost = (id) => {
    setPosts((prev) => prev.filter((p) => p.id !== id));
  };

  const getPost = (slug) => posts.find((p) => p.slug === slug);

  const filteredPosts = posts.filter((p) => {
    const matchesSearch =
      searchQuery === "" ||
      p.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      p.excerpt.toLowerCase().includes(searchQuery.toLowerCase()) ||
      p.tags.some((t) => t.toLowerCase().includes(searchQuery.toLowerCase()));
    const matchesCategory = activeCategory === "All" || p.category === activeCategory;
    return matchesSearch && matchesCategory;
  });

  const categories = ["All", ...new Set(posts.map((p) => p.category))];

  return (
    <BlogContext.Provider
      value={{
        posts,
        filteredPosts,
        categories,
        searchQuery,
        setSearchQuery,
        activeCategory,
        setActiveCategory,
        addPost,
        updatePost,
        deletePost,
        getPost,
      }}
    >
      {children}
    </BlogContext.Provider>
  );
}

export const useBlog = () => {
  const ctx = useContext(BlogContext);
  if (!ctx) throw new Error("useBlog must be used within BlogProvider");
  return ctx;
};
