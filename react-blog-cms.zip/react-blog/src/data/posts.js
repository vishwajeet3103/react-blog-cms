export const posts = [
  {
    id: 1,
    title: "Getting Started with React 18",
    slug: "getting-started-react-18",
    category: "React",
    author: "Alex Rivera",
    date: "2024-03-10",
    readTime: "5 min",
    cover: "https://images.unsplash.com/photo-1633356122544-f134324a6cee?w=800&q=80",
    excerpt:
      "React 18 ships concurrent rendering by default. Here's what changed and how to migrate your existing apps without breaking anything.",
    content: `React 18 is a major release that introduces concurrent features to the React ecosystem. The biggest change is that rendering is now interruptible — React can pause, resume, or abandon a render to keep the UI responsive.\n\n## What's New\n\n**Automatic Batching** — State updates inside timeouts, promises, and native event handlers are now batched automatically, just like updates inside React event handlers. This reduces unnecessary re-renders.\n\n**Transitions** — The new \`startTransition\` API lets you mark non-urgent updates so React can deprioritize them. Wrap slow state updates to keep typing and clicking snappy.\n\n**Suspense on the Server** — Server-side rendering now supports Suspense, enabling streaming HTML and selective hydration for faster time-to-interactive.\n\n## Migrating\n\nThe only required change is swapping \`ReactDOM.render\` for \`createRoot\`:\n\n\`\`\`js\nimport { createRoot } from 'react-dom/client';\nconst root = createRoot(document.getElementById('root'));\nroot.render(<App />);\n\`\`\`\n\nEverything else is opt-in. Your existing code will run without modification.`,
    tags: ["React", "JavaScript", "Frontend"],
  },
  {
    id: 2,
    title: "CSS Grid vs Flexbox: When to Use Which",
    slug: "css-grid-vs-flexbox",
    category: "CSS",
    author: "Priya Nair",
    date: "2024-03-05",
    readTime: "4 min",
    cover: "https://images.unsplash.com/photo-1507721999472-8ed4421c4af2?w=800&q=80",
    excerpt:
      "Both CSS Grid and Flexbox solve layout problems, but they solve different ones. Learn to pick the right tool for every situation.",
    content: `Flexbox and Grid are both powerful layout systems, and the common advice — "use Flexbox for 1D, Grid for 2D" — is a good start but not the full picture.\n\n## Flexbox Strengths\n\nFlexbox is built for **content-driven layouts**. When you don't know how many items you'll have, or items vary in size and you want them to adjust gracefully, Flexbox is your friend. Navigation bars, button groups, card rows — anywhere items flow in one axis.\n\n## Grid Strengths\n\nGrid is built for **layout-driven designs**. You define the grid first, then place items into it. This makes it perfect for page-level layouts, dashboards, and any time you need items to align across both rows and columns simultaneously.\n\n## The Practical Rule\n\n- If the layout comes from the **content** → Flexbox  \n- If the content is placed into a **predefined layout** → Grid  \n- They compose: use Grid for the page shell, Flexbox inside each Grid cell.\n\n## A Quick Example\n\n\`\`\`css\n/* Page shell — Grid */\n.page { display: grid; grid-template-columns: 240px 1fr; }\n\n/* Nav items inside sidebar — Flexbox */\n.sidebar { display: flex; flex-direction: column; gap: 8px; }\n\`\`\``,
    tags: ["CSS", "Layout", "Frontend"],
  },
  {
    id: 3,
    title: "Node.js Streams: A Practical Guide",
    slug: "nodejs-streams-practical",
    category: "Node.js",
    author: "Marcus Chen",
    date: "2024-02-28",
    readTime: "7 min",
    cover: "https://images.unsplash.com/photo-1558494949-ef010cbdcc31?w=800&q=80",
    excerpt:
      "Streams let you process data piece-by-piece instead of loading everything into memory. Master them and you'll handle files, HTTP, and databases far more efficiently.",
    content: `Node.js streams are one of its most powerful — and most misunderstood — features. The core idea: instead of reading an entire file into memory before processing it, streams let you process data in chunks as it arrives.\n\n## Four Stream Types\n\n- **Readable** — Source of data (fs.createReadStream, HTTP request body)\n- **Writable** — Destination (fs.createWriteStream, HTTP response)\n- **Duplex** — Both readable and writable (TCP sockets)\n- **Transform** — Duplex that modifies data (zlib compression, crypto)\n\n## Piping Streams\n\nThe \`pipe\` method connects a readable to a writable and handles backpressure automatically:\n\n\`\`\`js\nconst { createReadStream, createWriteStream } = require('fs');\nconst { createGzip } = require('zlib');\n\ncreateReadStream('input.txt')\n  .pipe(createGzip())\n  .pipe(createWriteStream('input.txt.gz'));\n\`\`\`\n\nThis compresses a file without ever holding the whole file in memory — even if it's 10 GB.\n\n## When to Use Streams\n\n- Reading/writing large files\n- HTTP request/response bodies\n- Real-time data (logs, events)\n- ETL pipelines`,
    tags: ["Node.js", "Backend", "Performance"],
  },
  {
    id: 4,
    title: "Understanding TypeScript Generics",
    slug: "typescript-generics",
    category: "TypeScript",
    author: "Sara Müller",
    date: "2024-02-20",
    readTime: "6 min",
    cover: "https://images.unsplash.com/photo-1516116216624-53e697fedbea?w=800&q=80",
    excerpt:
      "Generics are what make TypeScript genuinely powerful. Stop writing the same type logic twice — write it once and let it work for any type.",
    content: `Generics let you write reusable, type-safe code without sacrificing flexibility. Think of them as type variables — placeholders that get filled in when you use the function or class.\n\n## Basic Syntax\n\n\`\`\`ts\nfunction identity<T>(value: T): T {\n  return value;\n}\n\nidentity<string>('hello'); // returns string\nidentity<number>(42);      // returns number\n\`\`\`\n\nTypeScript can usually infer the type argument, so you can just write \`identity('hello')\`.\n\n## Generic Constraints\n\nUse \`extends\` to restrict what types are allowed:\n\n\`\`\`ts\nfunction getLength<T extends { length: number }>(item: T): number {\n  return item.length;\n}\n\ngetLength('hello');   // ✓\ngetLength([1, 2, 3]); // ✓\ngetLength(42);        // ✗ — number has no .length\n\`\`\`\n\n## Generic Interfaces\n\n\`\`\`ts\ninterface ApiResponse<T> {\n  data: T;\n  status: number;\n  message: string;\n}\n\ntype UserResponse = ApiResponse<{ id: number; name: string }>;\n\`\`\`\n\nThis pattern is invaluable for API clients — define it once, use it everywhere.`,
    tags: ["TypeScript", "JavaScript", "Types"],
  },
  {
    id: 5,
    title: "REST vs GraphQL: Choosing Wisely",
    slug: "rest-vs-graphql",
    category: "API Design",
    author: "Alex Rivera",
    date: "2024-02-14",
    readTime: "5 min",
    cover: "https://images.unsplash.com/photo-1558494949-ef010cbdcc31?w=800&q=80",
    excerpt:
      "GraphQL isn't a replacement for REST — it's a different tool for different problems. Here's a clear framework for choosing between them.",
    content: `The REST vs GraphQL debate is often framed wrong. Both are valid API paradigms; the right choice depends on your use case.\n\n## REST Strengths\n\n- Simple mental model — resources and HTTP verbs\n- Excellent caching with HTTP (ETags, Cache-Control)\n- Easy to understand for any HTTP client\n- Great for simple CRUD with stable, predictable shapes\n\n## GraphQL Strengths\n\n- Client specifies exactly what data it needs (no over/under-fetching)\n- Single endpoint, strongly typed schema\n- Excellent for complex, nested data relationships\n- Ideal for mobile clients where bandwidth matters\n\n## Decision Framework\n\n| Situation | Choose |\n|---|---|\n| Public API consumed by many clients | REST |\n| Mobile apps with bandwidth concerns | GraphQL |\n| Simple CRUD service | REST |\n| Complex frontend with many data relationships | GraphQL |\n| Team already knows REST | REST |\n| Aggregating multiple backends | GraphQL |\n\n## The Hybrid Approach\n\nMany teams run both: REST for authentication and simple resources, GraphQL for the main data graph. Don't treat it as either/or.`,
    tags: ["API", "GraphQL", "REST", "Backend"],
  },
  {
    id: 6,
    title: "Docker for Frontend Developers",
    slug: "docker-for-frontend",
    category: "DevOps",
    author: "Priya Nair",
    date: "2024-02-08",
    readTime: "6 min",
    cover: "https://images.unsplash.com/photo-1605745341112-85968b19335b?w=800&q=80",
    excerpt:
      "You don't need to be a DevOps engineer to benefit from Docker. Learn the 20% that covers 80% of frontend use cases.",
    content: `Docker can feel intimidating, but frontend developers only need a small subset of its features. Here's the practical minimum.\n\n## Why Bother?\n\n- Consistent environment across dev machines and CI\n- No more "works on my machine"\n- Easy to spin up databases or backend services locally\n\n## A Minimal React Dockerfile\n\n\`\`\`dockerfile\nFROM node:20-alpine AS build\nWORKDIR /app\nCOPY package*.json ./\nRUN npm ci\nCOPY . .\nRUN npm run build\n\nFROM nginx:alpine\nCOPY --from=build /app/build /usr/share/nginx/html\nEXPOSE 80\n\`\`\`\n\nThis is a multi-stage build: stage one compiles your React app, stage two serves it with nginx. The final image is tiny (~25 MB).\n\n## Useful Commands\n\n\`\`\`bash\ndocker build -t my-app .        # build image\ndocker run -p 3000:80 my-app    # run it\ndocker compose up               # start all services\n\`\`\`\n\n## Docker Compose for Local Dev\n\nUse Compose to run your frontend + backend + database together with one command. Define each service in \`docker-compose.yml\` and they'll share a network automatically.`,
    tags: ["Docker", "DevOps", "Frontend"],
  },
];

export const categories = [...new Set(posts.map((p) => p.category))];
export const authors = [...new Set(posts.map((p) => p.author))];
