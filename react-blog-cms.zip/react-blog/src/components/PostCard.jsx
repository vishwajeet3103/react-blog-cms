import { Link } from "react-router-dom";
import "./PostCard.css";

export default function PostCard({ post, index = 0 }) {
  return (
    <article
      className="post-card fade-up"
      style={{ animationDelay: `${index * 0.07}s` }}
    >
      <Link to={`/post/${post.slug}`} className="post-card__cover-link">
        <div className="post-card__cover">
          <img src={post.cover} alt={post.title} loading="lazy" />
          <span className="post-card__category">{post.category}</span>
        </div>
      </Link>
      <div className="post-card__body">
        <div className="post-card__meta">
          <span>{post.author}</span>
          <span className="post-card__dot">·</span>
          <span>{post.date}</span>
          <span className="post-card__dot">·</span>
          <span>{post.readTime} read</span>
        </div>
        <Link to={`/post/${post.slug}`}>
          <h2 className="post-card__title">{post.title}</h2>
        </Link>
        <p className="post-card__excerpt">{post.excerpt}</p>
        <div className="post-card__tags">
          {post.tags.slice(0, 3).map((tag) => (
            <span key={tag} className="post-card__tag">{tag}</span>
          ))}
        </div>
      </div>
    </article>
  );
}
