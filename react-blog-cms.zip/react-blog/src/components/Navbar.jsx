import { useState } from "react";
import { Link, useNavigate, useLocation } from "react-router-dom";
import { useBlog } from "../context/BlogContext";
import "./Navbar.css";

export default function Navbar() {
  const { setSearchQuery } = useBlog();
  const [query, setQuery] = useState("");
  const [menuOpen, setMenuOpen] = useState(false);
  const navigate = useNavigate();
  const location = useLocation();

  const handleSearch = (e) => {
    e.preventDefault();
    setSearchQuery(query);
    navigate("/");
  };

  const handleSearchChange = (e) => {
    setQuery(e.target.value);
    if (location.pathname === "/") setSearchQuery(e.target.value);
  };

  const clearSearch = () => {
    setQuery("");
    setSearchQuery("");
  };

  return (
    <header className="navbar">
      <div className="container navbar__inner">
        <Link to="/" className="navbar__brand" onClick={clearSearch}>
          <span className="navbar__brand-script">The</span>
          <span className="navbar__brand-serif">Dev Journal</span>
        </Link>

        <form className="navbar__search" onSubmit={handleSearch}>
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            <circle cx="11" cy="11" r="8"/><path d="m21 21-4.35-4.35"/>
          </svg>
          <input
            type="text"
            placeholder="Search articles…"
            value={query}
            onChange={handleSearchChange}
          />
          {query && (
            <button type="button" className="navbar__clear" onClick={clearSearch}>×</button>
          )}
        </form>

        <nav className={`navbar__links ${menuOpen ? "open" : ""}`}>
          <Link to="/" onClick={() => { clearSearch(); setMenuOpen(false); }}>Home</Link>
          <Link to="/cms" onClick={() => setMenuOpen(false)}>CMS</Link>
          <Link to="/cms/new" className="navbar__cta" onClick={() => setMenuOpen(false)}>
            + Write
          </Link>
        </nav>

        <button className="navbar__hamburger" onClick={() => setMenuOpen(!menuOpen)}>
          <span /><span /><span />
        </button>
      </div>
    </header>
  );
}
