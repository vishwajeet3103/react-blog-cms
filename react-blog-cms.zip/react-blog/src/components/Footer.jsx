import "./Footer.css";

export default function Footer() {
  return (
    <footer className="footer">
      <div className="container footer__inner">
        <div>
          <p className="footer__brand">The Dev Journal</p>
          <p className="footer__tagline">Thoughtful writing for thoughtful developers.</p>
        </div>
        <p className="footer__copy">© {new Date().getFullYear()} — Built with React</p>
      </div>
    </footer>
  );
}
