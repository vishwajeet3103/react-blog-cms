import { useState, useEffect } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { useBlog } from "../context/BlogContext";
import "./PostEditor.css";

const EMPTY = { title: "", category: "", author: "", excerpt: "", content: "", cover: "", tags: "" };

export default function PostEditor() {
  const { id } = useParams();
  const { addPost, updatePost, posts } = useBlog();
  const navigate = useNavigate();
  const isEditing = Boolean(id);

  const [form, setForm] = useState(EMPTY);
  const [errors, setErrors] = useState({});
  const [preview, setPreview] = useState(false);
  const [saved, setSaved] = useState(false);

  useEffect(() => {
    if (isEditing) {
      const post = posts.find((p) => p.id === Number(id));
      if (post) {
        setForm({ ...post, tags: post.tags.join(", ") });
      }
    }
  }, [id, isEditing, posts]);

  const validate = () => {
    const e = {};
    if (!form.title.trim()) e.title = "Title is required";
    if (!form.category.trim()) e.category = "Category is required";
    if (!form.author.trim()) e.author = "Author is required";
    if (!form.excerpt.trim()) e.excerpt = "Excerpt is required";
    if (!form.content.trim()) e.content = "Content is required";
    return e;
  };

  const handleChange = (field) => (e) => {
    setForm((prev) => ({ ...prev, [field]: e.target.value }));
    if (errors[field]) setErrors((prev) => ({ ...prev, [field]: "" }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    const e2 = validate();
    if (Object.keys(e2).length) { setErrors(e2); return; }

    const data = { ...form, tags: form.tags.split(",").map((t) => t.trim()).filter(Boolean) };

    if (isEditing) {
      updatePost(Number(id), data);
      setSaved(true);
      setTimeout(() => navigate(`/post/${data.title.toLowerCase().replace(/\s+/g, "-").replace(/[^a-z0-9-]/g, "")}`), 800);
    } else {
      const newPost = addPost(data);
      setSaved(true);
      setTimeout(() => navigate(`/post/${newPost.slug}`), 800);
    }
  };

  return (
    <div className="editor container fade-up">
      <div className="editor__header">
        <h1 className="editor__title">{isEditing ? "Edit Post" : "New Post"}</h1>
        <div className="editor__header-actions">
          <button
            type="button"
            className={`editor__preview-btn ${preview ? "active" : ""}`}
            onClick={() => setPreview(!preview)}
          >
            {preview ? "✏️ Edit" : "👁 Preview"}
          </button>
        </div>
      </div>

      {saved && (
        <div className="editor__toast fade-in">✓ Post saved successfully!</div>
      )}

      <form className="editor__form" onSubmit={handleSubmit}>
        <div className="editor__row">
          <div className="editor__field">
            <label>Title *</label>
            <input
              type="text"
              value={form.title}
              onChange={handleChange("title")}
              placeholder="Enter post title…"
              className={errors.title ? "error" : ""}
            />
            {errors.title && <span className="editor__error">{errors.title}</span>}
          </div>
        </div>

        <div className="editor__row two-col">
          <div className="editor__field">
            <label>Category *</label>
            <input
              type="text"
              value={form.category}
              onChange={handleChange("category")}
              placeholder="e.g. React, CSS, Node.js"
              className={errors.category ? "error" : ""}
            />
            {errors.category && <span className="editor__error">{errors.category}</span>}
          </div>
          <div className="editor__field">
            <label>Author *</label>
            <input
              type="text"
              value={form.author}
              onChange={handleChange("author")}
              placeholder="Author name"
              className={errors.author ? "error" : ""}
            />
            {errors.author && <span className="editor__error">{errors.author}</span>}
          </div>
        </div>

        <div className="editor__row">
          <div className="editor__field">
            <label>Cover Image URL</label>
            <input
              type="url"
              value={form.cover}
              onChange={handleChange("cover")}
              placeholder="https://images.unsplash.com/…"
            />
          </div>
        </div>

        <div className="editor__row">
          <div className="editor__field">
            <label>Tags <span>(comma-separated)</span></label>
            <input
              type="text"
              value={form.tags}
              onChange={handleChange("tags")}
              placeholder="React, JavaScript, Frontend"
            />
          </div>
        </div>

        <div className="editor__row">
          <div className="editor__field">
            <label>Excerpt *</label>
            <textarea
              rows={3}
              value={form.excerpt}
              onChange={handleChange("excerpt")}
              placeholder="Short summary shown on the card and post header…"
              className={errors.excerpt ? "error" : ""}
            />
            {errors.excerpt && <span className="editor__error">{errors.excerpt}</span>}
          </div>
        </div>

        <div className="editor__row">
          <div className="editor__field">
            <label>Content * <span>(Markdown supported)</span></label>
            {preview ? (
              <div
                className="editor__preview-content"
                dangerouslySetInnerHTML={{
                  __html: form.content
                    .replace(/```(\w*)\n([\s\S]*?)```/g, (_, lang, code) =>
                      `<pre class="code-block"><code>${code.replace(/</g, "&lt;")}</code></pre>`)
                    .replace(/`([^`]+)`/g, "<code class='inline-code'>$1</code>")
                    .replace(/^## (.+)$/gm, "<h2>$1</h2>")
                    .replace(/\*\*(.+?)\*\*/g, "<strong>$1</strong>")
                    .replace(/\n\n/g, "</p><p>")
                    .replace(/^(?!<)(.+)$/gm, (l) => l.trim() ? `<p>${l}</p>` : l)
                }}
              />
            ) : (
              <textarea
                rows={18}
                value={form.content}
                onChange={handleChange("content")}
                placeholder="Write your post in Markdown…&#10;&#10;## Section Heading&#10;&#10;Your paragraph text here.&#10;&#10;```js&#10;const x = 1;&#10;```"
                className={`editor__content-area${errors.content ? " error" : ""}`}
              />
            )}
            {errors.content && <span className="editor__error">{errors.content}</span>}
          </div>
        </div>

        <div className="editor__submit-row">
          <button type="button" onClick={() => navigate(-1)} className="editor__btn-cancel">
            Cancel
          </button>
          <button type="submit" className="editor__btn-submit">
            {isEditing ? "Save Changes" : "Publish Post"}
          </button>
        </div>
      </form>
    </div>
  );
}
