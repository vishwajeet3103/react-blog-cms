import { useBlog } from "../context/BlogContext";
import PostCard from "../components/PostCard";
import "./Home.css";

export default function Home() {
  const { filteredPosts, categories, activeCategory, setActiveCategory, searchQuery } = useBlog();
  const featured = filteredPosts[0];
  const rest = filteredPosts.slice(1);

  return (
    <main className="home">
      <div className="container">

        {/* Hero */}
        {!searchQuery && activeCategory === "All" && featured && (
          <section className="home__hero fade-up">
            <div className="home__hero-image">
              <img src={featured.cover} alt={featured.title} />
              <span className="home__hero-badge">{featured.category}</span>
            </div>
            <div className="home__hero-content">
              <p className="home__hero-label">Featured Post</p>
              <h1 className="home__hero-title">{featured.title}</h1>
              <p className="home__hero-excerpt">{featured.excerpt}</p>
              <div className="home__hero-meta">
                <span>{featured.author}</span>
                <span>·</span>
                <span>{featured.date}</span>
                <span>·</span>
                <span>{featured.readTime} read</span>
              </div>
              <a href={`/post/${featured.slug}`} className="home__hero-btn">
                Read Article →
              </a>
            </div>
          </section>
        )}

        {/* Categories */}
        <div className="home__filters fade-up">
          {categories.map((cat) => (
            <button
              key={cat}
              className={`home__filter-btn ${activeCategory === cat ? "active" : ""}`}
              onClick={() => setActiveCategory(cat)}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* Results info */}
        {(searchQuery || activeCategory !== "All") && (
          <p className="home__results-info fade-in">
            {filteredPosts.length === 0
              ? "No articles found."
              : `${filteredPosts.length} article${filteredPosts.length !== 1 ? "s" : ""} found`}
            {searchQuery && <> for <strong>"{searchQuery}"</strong></>}
          </p>
        )}

        {/* Grid */}
        <section className="home__grid">
          {(searchQuery || activeCategory !== "All" ? filteredPosts : rest).map((post, i) => (
            <PostCard key={post.id} post={post} index={i} />
          ))}
        </section>

        {filteredPosts.length === 0 && (
          <div className="home__empty fade-in">
            <p>No articles match your search.</p>
          </div>
        )}
      </div>
    </main>
  );
}
