import { useParams, useNavigate, Link } from "react-router-dom";
import { useBlog } from "../context/BlogContext";
import "./PostDetail.css";

function renderMarkdown(text) {
  return text
    .replace(/```(\w*)\n([\s\S]*?)```/g, (_, lang, code) =>
      `<pre class="code-block"><code class="lang-${lang}">${code.replace(/</g, "&lt;").replace(/>/g, "&gt;")}</code></pre>`
    )
    .replace(/`([^`]+)`/g, "<code class='inline-code'>$1</code>")
    .replace(/^## (.+)$/gm, "<h2>$1</h2>")
    .replace(/^### (.+)$/gm, "<h3>$1</h3>")
    .replace(/\*\*(.+?)\*\*/g, "<strong>$1</strong>")
    .replace(/\*(.+?)\*/g, "<em>$1</em>")
    .replace(/^\| (.+) \|$/gm, (_, row) => {
      if (row.includes("---")) return "";
      const cells = row.split(" | ").map((c) => `<td>${c}</td>`).join("");
      return `<tr>${cells}</tr>`;
    })
    .replace(/(<tr>[\s\S]*?<\/tr>)/g, "<table>$1</table>")
    .replace(/^- (.+)$/gm, "<li>$1</li>")
    .replace(/(<li>[\s\S]*?<\/li>)/g, (match) => `<ul>${match}</ul>`)
    .replace(/\n\n/g, "</p><p>")
    .replace(/^(?!<[hupct])(.+)$/gm, (line) =>
      line.trim() && !line.startsWith("<") ? `<p>${line}</p>` : line
    );
}

export default function PostDetail() {
  const { slug } = useParams();
  const { getPost, deletePost, posts } = useBlog();
  const navigate = useNavigate();
  const post = getPost(slug);

  if (!post) {
    return (
      <div className="post-detail__not-found container">
        <h2>Post not found</h2>
        <Link to="/">← Back to Home</Link>
      </div>
    );
  }

  const currentIndex = posts.findIndex((p) => p.slug === slug);
  const prev = posts[currentIndex + 1];
  const next = posts[currentIndex - 1];

  const handleDelete = () => {
    if (window.confirm("Delete this post permanently?")) {
      deletePost(post.id);
      navigate("/");
    }
  };

  return (
    <article className="post-detail fade-in">
      <div className="post-detail__hero">
        <img src={post.cover} alt={post.title} className="post-detail__cover" />
        <div className="post-detail__hero-overlay" />
        <div className="post-detail__hero-content container">
          <span className="post-detail__category">{post.category}</span>
          <h1 className="post-detail__title">{post.title}</h1>
          <div className="post-detail__meta">
            <span>{post.author}</span>
            <span>·</span>
            <span>{post.date}</span>
            <span>·</span>
            <span>{post.readTime} read</span>
          </div>
        </div>
      </div>

      <div className="container post-detail__layout">
        <aside className="post-detail__sidebar">
          <div className="post-detail__tags">
            <p className="post-detail__sidebar-label">Tags</p>
            {post.tags.map((t) => (
              <span key={t} className="post-detail__tag">{t}</span>
            ))}
          </div>
          <div className="post-detail__actions">
            <p className="post-detail__sidebar-label">Actions</p>
            <Link to={`/cms/edit/${post.id}`} className="post-detail__action-btn edit">
              ✏️ Edit Post
            </Link>
            <button onClick={handleDelete} className="post-detail__action-btn delete">
              🗑 Delete Post
            </button>
          </div>
        </aside>

        <div className="post-detail__content">
          <p className="post-detail__lead">{post.excerpt}</p>
          <div
            className="post-detail__body"
            dangerouslySetInnerHTML={{ __html: renderMarkdown(post.content) }}
          />

          <div className="post-detail__nav">
            {next && (
              <Link to={`/post/${next.slug}`} className="post-detail__nav-link">
                <span>← Newer</span>
                <strong>{next.title}</strong>
              </Link>
            )}
            {prev && (
              <Link to={`/post/${prev.slug}`} className="post-detail__nav-link right">
                <span>Older →</span>
                <strong>{prev.title}</strong>
              </Link>
            )}
          </div>
        </div>
      </div>
    </article>
  );
}
