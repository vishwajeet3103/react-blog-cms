import { Link } from "react-router-dom";
import { useBlog } from "../context/BlogContext";
import "./CMS.css";

export default function CMS() {
  const { posts, deletePost } = useBlog();

  const handleDelete = (id, title) => {
    if (window.confirm(`Delete "${title}"?`)) deletePost(id);
  };

  return (
    <div className="cms container fade-up">
      <div className="cms__header">
        <div>
          <h1 className="cms__title">CMS Dashboard</h1>
          <p className="cms__subtitle">{posts.length} articles total</p>
        </div>
        <Link to="/cms/new" className="cms__btn-new">+ New Post</Link>
      </div>

      <div className="cms__table-wrap">
        <table className="cms__table">
          <thead>
            <tr>
              <th>Title</th>
              <th>Category</th>
              <th>Author</th>
              <th>Date</th>
              <th>Read Time</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {posts.map((post) => (
              <tr key={post.id}>
                <td className="cms__col-title">
                  <Link to={`/post/${post.slug}`}>{post.title}</Link>
                </td>
                <td>
                  <span className="cms__badge">{post.category}</span>
                </td>
                <td>{post.author}</td>
                <td>{post.date}</td>
                <td>{post.readTime}</td>
                <td className="cms__col-actions">
                  <Link to={`/cms/edit/${post.id}`} className="cms__action-btn edit">Edit</Link>
                  <button
                    className="cms__action-btn delete"
                    onClick={() => handleDelete(post.id, post.title)}
                  >
                    Delete
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
