# The Dev Journal — React Blog CMS

A full-featured Blog & Content Management System built with **React 18**, **React Router v6**, and **Context API**.

## Features

- **Blog Feed** — Responsive grid with featured hero post
- **Post Detail** — Markdown rendering with code highlighting, prev/next navigation
- **CMS Dashboard** — Table view of all posts with edit/delete actions
- **Post Editor** — Create and edit posts with live Markdown preview
- **Search** — Real-time title, excerpt, and tag search
- **Category Filter** — Filter posts by category
- **Persistence** — All changes saved to `localStorage`
- **Responsive** — Works on mobile, tablet, and desktop

## Tech Stack

| Layer | Technology |
|---|---|
| UI Library | React 18 |
| Routing | React Router v6 |
| State Management | Context API + useReducer pattern |
| Styling | Plain CSS with CSS Variables |
| Storage | localStorage (no backend required) |

## Project Structure

```
src/
├── components/
│   ├── Navbar.jsx / .css
│   ├── PostCard.jsx / .css
│   └── Footer.jsx / .css
├── context/
│   └── BlogContext.jsx       # Global state: posts, search, filters
├── data/
│   └── posts.js              # Seed data (6 sample posts)
├── pages/
│   ├── Home.jsx / .css       # Feed + hero + category filters
│   ├── PostDetail.jsx / .css # Full post with Markdown renderer
│   ├── CMS.jsx / .css        # Admin dashboard table
│   └── PostEditor.jsx / .css # Create / edit form with preview
├── styles/
│   └── global.css            # CSS variables, resets, animations
└── App.jsx                   # Router setup
```

## Getting Started

```bash
# 1. Install dependencies
npm install

# 2. Start dev server
npm start

# 3. Open in browser
# http://localhost:3000
```

## Pages & Routes

| Route | Page |
|---|---|
| `/` | Home feed |
| `/post/:slug` | Post detail |
| `/cms` | CMS dashboard |
| `/cms/new` | Create new post |
| `/cms/edit/:id` | Edit existing post |

## How to Add a Post

1. Click **"+ Write"** in the navbar or **"+ New Post"** in the CMS dashboard
2. Fill in title, category, author, excerpt, and content (Markdown supported)
3. Optionally add a cover image URL and tags
4. Click **"Publish Post"** — it's saved immediately and you're redirected to the post

## Markdown Support

The post editor and detail page support:

- `## Headings`, `### Sub-headings`
- `**bold**`, `*italic*`
- `` `inline code` ``
- ` ```js ` fenced code blocks with language label
- `- list items`
- Markdown tables

## Notes

- No backend or database is required — data lives in `localStorage`
- Deleting all posts and refreshing will reload the 6 seed posts
- Cover image field accepts any public image URL (Unsplash works great)
